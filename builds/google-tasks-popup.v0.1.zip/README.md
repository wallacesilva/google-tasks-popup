# Google Tasks Popup
Show minimal Google Tasks popup. No advanced features.

This open the url: https://mail.google.com/tasks/ig (login required, of course)

On click open popup with dimensions 335px / 350px
